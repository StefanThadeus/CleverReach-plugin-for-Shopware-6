<?php

namespace Logeecom\CleverReachPlugin\BusinessLogic\Interfaces;

interface AttributeServiceInterface
{
    public function addAttributes(): void;
}