<?php

namespace Logeecom\CleverReachPlugin\BusinessLogic\Repositories;

class TokenRepository
{

}